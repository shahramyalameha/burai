package org.jcodec.containers.mp4;

public class TimecodeBoxes extends Boxes {
    //intentionally left blank
}