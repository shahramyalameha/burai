package org.jcodec.codecs.mjpeg.tools;

public class AssertionException extends RuntimeException {

	public AssertionException(String string) {
		super(string);
	}

}
