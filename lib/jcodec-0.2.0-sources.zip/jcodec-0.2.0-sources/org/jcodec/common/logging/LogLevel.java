package org.jcodec.common.logging;

public enum LogLevel {
    DEBUG, INFO, WARN, ERROR
}