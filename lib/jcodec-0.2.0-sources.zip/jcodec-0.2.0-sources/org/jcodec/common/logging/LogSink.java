package org.jcodec.common.logging;

public interface LogSink {
    void postMessage(Message msg);
}